package arbolb;

import java.util.HashSet;
import java.util.Scanner;


public class Parcial1 {
	
	public static HashSet<Integer> union(HashSet<Integer> c1, HashSet<Integer> c2)
	{
		HashSet<Integer> rta = new HashSet<>();
		rta.addAll(c1);
		rta.addAll(c2);
		return rta;
	}
	
	public static HashSet<Integer> interseccion(HashSet<Integer> c3, HashSet<Integer> c4)
	{
		HashSet<Integer> rta1 = new HashSet<>();
		for (int l : c3) {
			for (int � : c4) {
				if (l==�)
				{
					rta1.add(l);
				}
			}
		
		}
		return rta1;
	}
	
	public static HashSet<Integer> diferencia(HashSet<Integer> a1, HashSet<Integer> a2)
	{
		HashSet<Integer> rta2 = new HashSet<>();
		for (int elemento : a1) {
			rta2.add(elemento);
			for (int elemento2 : a2) {
				if (elemento==elemento2)
				{
					rta2.remove(elemento);
				}
			}
		}
		return rta2;
	}
	
	public static HashSet<Integer> diferenciaSim(HashSet<Integer> b1, HashSet<Integer> b2)
	{
		HashSet<Integer> rta3 = new HashSet<>();
		HashSet<Integer> temp = new HashSet<>(b1);
		temp.retainAll(b2);
		rta3.addAll(b1);
		rta3.addAll(b2);
		rta3.removeAll(temp);
		
		return rta3;
	}

	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		HashSet<Integer> conjuntoA = new HashSet<>();
		HashSet<Integer> conjuntoB = new HashSet<>();
		HashSet<Integer> conjuntoC = new HashSet<>();
		HashSet<Integer> conjuntoD = new HashSet<>();
		
		//CONJUNTO A
		for (int elemento=10; elemento<30;elemento++)
		{
			conjuntoA.add(elemento);
		}
		
		//CONJUNTO B
		conjuntoB.add(0);
		conjuntoB.add(2);
		conjuntoB.add(4);
		conjuntoB.add(6);
		conjuntoB.add(12);
		conjuntoB.add(24);
		conjuntoB.add(48);
		
		
		//CONJUNTO C
		
		for (int i=0;i<46;i++) 
		{
			if (i%4==2)
			{
				conjuntoC.add(i);
			}
		}
		
		
		//CONJUNTO D
		conjuntoD.add(2);
		conjuntoD.add(3);
		conjuntoD.add(5);
		conjuntoD.add(7);
		conjuntoD.add(11);
		conjuntoD.add(13);
		conjuntoD.add(17);
		conjuntoD.add(19);
		conjuntoD.add(23);
		conjuntoD.add(29);
		conjuntoD.add(31);
		conjuntoD.add(37);
		
		
		HashSet<Integer> difA = diferenciaSim(diferencia(conjuntoA,conjuntoC),interseccion(conjuntoB,conjuntoD));
		
		
		HashSet<Integer> difB = diferenciaSim(interseccion(conjuntoB,conjuntoD),conjuntoC);
		HashSet<Integer> ejercicioB = diferencia(difB,union(conjuntoA,conjuntoD));
		

		HashSet<Integer> interlarga = interseccion(interseccion(conjuntoA,conjuntoB),conjuntoC);
		HashSet<Integer> unionmedia = union(diferencia(conjuntoA,conjuntoC),diferencia(conjuntoB,conjuntoC));
		HashSet<Integer> ejercicioD = union(interlarga,unionmedia);
		
		System.out.println("Primer resultado:");
		System.out.println(difA);
		System.out.println("Segundo resultado:");
		System.out.println(ejercicioB);
		System.out.println("Tercer resultado:");
		System.out.println(ejercicioD);
		
	}}
	

