package arbolb;

import java.util.HashSet;
import java.util.Scanner;


public class pruebas {

	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		HashSet<Integer> conjuntoA = new HashSet<>();
		HashSet<Integer> conjuntoB = new HashSet<>();
		
		System.out.println("Ingrese el Conjunto A:");
		for (int i =0; i<5; i++) {
			System.out.print("Un numero: ");
			int aux = sc.nextInt();
			
			conjuntoA.add(aux);
		}
		System.out.println("Ingrese el Conjunto B:");
		for (int j=0; j<5; j++) {
			System.out.print("Un numero: ");
			int aux2 = sc.nextInt();
			conjuntoB.add(aux2);
		}
		
	System.out.println("Que operacion desea realizar con dichos conjuntos");
	System.out.println("1. Union  ");
	System.out.println("2. Interseccion");
	System.out.println("3. Diferencia");
	System.out.println("4. Diferencia simetrica");
	int opcion = sc.nextInt();
	switch (opcion){
		case 1: 
			HashSet<Integer> conjuntoUnion = new HashSet<>();
			for (int elemento : conjuntoA) {
				conjuntoUnion.add(elemento);
			}
			for (int elemento : conjuntoB) {
				conjuntoUnion.add(elemento);
			}
			System.out.println("La union de dichos conjuntos es: "+conjuntoUnion);
			break;
		case 2:
			HashSet<Integer> conjuntoInterseccion =new HashSet<>();
			for (int elemento : conjuntoA) {
				for (int elemento2 : conjuntoB) {
					if (elemento==elemento2)
					{
						conjuntoInterseccion.add(elemento);
					}
				}
			}
			System.out.println("La Interseccion de dichos conjuntos es: "+conjuntoInterseccion);
			break;
		case 3:
			HashSet<Integer> conjuntoDiferencia =new HashSet<>();
			for (int elemento : conjuntoA) {
				conjuntoDiferencia.add(elemento);
				for (int elemento2 : conjuntoB) {
					if (elemento==elemento2)
					{
						conjuntoDiferencia.remove(elemento);
					}
				}
			}
			System.out.println("La Diferencia de dichos conjuntos (A-B) es: "+conjuntoDiferencia);
			HashSet<Integer> conjuntoDiferencia2 =new HashSet<>();
			for (int elemento3 : conjuntoB) {
				conjuntoDiferencia2.add(elemento3);
				for (int elemento4 : conjuntoA) {
					if (elemento3==elemento4)
					{
						conjuntoDiferencia2.remove(elemento3);
					}
				}
			}
			System.out.println("La Diferencia de dichos conjuntos (B-A) es: "+conjuntoDiferencia2);
			break;
		case 4:
			HashSet<Integer> conjuntoAB = new HashSet<>();
			for (int elemento : conjuntoA) {
				conjuntoAB.add(elemento);
			}
			for (int elemento : conjuntoB) {
				conjuntoAB.add(elemento);
			}
			HashSet<Integer> conjuntoAintB = new HashSet<>();
			for (int elemento : conjuntoA) {
				for (int elemento2 : conjuntoB) {
					if (elemento==elemento2)
					{
						conjuntoAintB.add(elemento);
					}
				}
			}
			HashSet<Integer> conjuntoDiferenciaSimetrica =new HashSet<>();
			for (int elemento : conjuntoAB) {
				conjuntoDiferenciaSimetrica.add(elemento);
				for (int elemento2 : conjuntoAintB) {
					if (elemento==elemento2)
					{
						conjuntoDiferenciaSimetrica.remove(elemento);
					}
				}
			}
			System.out.println("La Diferencia simetrica de dichos conjuntos es: "+conjuntoDiferenciaSimetrica);
			
			
			
			break;
		
		
	}
		
	System.out.println("A = "+conjuntoA);
	System.out.println("B = "+conjuntoB);
	
	
	
}}
