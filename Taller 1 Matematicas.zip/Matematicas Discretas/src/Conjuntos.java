import java.util.HashSet;
import java.util.Set;

public class Conjuntos {

	public static void main(String[] args) {
	HashSet<Integer> A=new HashSet<>();
	for (int i=1; i<25;i++)
	{
		A.add(i);
	}
	System.out.println(A);
	
	HashSet<Integer> B=new HashSet<>();
	for (int j=4;j<21;j+=2)
	{
		B.add(j);
	}
	System.out.println(B);
	
	HashSet<Integer> C=new HashSet<>();
	for (int k=1;k<28;k+=3)
	{
		C.add(k);
	}
	System.out.println(C);
	
	HashSet<Integer> D=new HashSet<>();		
	D.add(2);
	D.add(3);
	D.add(5);
	D.add(7);
	D.add(11);
	D.add(13);
	D.add(17);
	D.add(19);
	D.add(23);
	D.add(29);
	D.add(31);
	D.add(37);
	
	System.out.println(D);
	HashSet<Integer> Parte1=new HashSet<>();
	Parte1.addAll(union(A,B));
	System.out.println("Operacion numero1");
	System.out.println(interseccion(Parte1,C));
	
	
	HashSet<Integer> Parte2=new HashSet<>();
	Parte2.addAll(interseccion(A,C));
	
	HashSet<Integer> P1=new HashSet<>();
	P1.addAll(diferencia(Parte2,D));
	
	HashSet<Integer> P2=new HashSet<>();
	P2.addAll(diferencia(D,Parte2));
	
	System.out.println("Operacion numero2");
	System.out.println(union(P1,P2));
	
	
	HashSet<Integer> Parte3=new HashSet<>();
	Parte3.addAll(union(C,D));
	
	System.out.println("Operacion numero 3");
	System.out.println(diferencia(A,Parte3));
	
	
	

	}
	
	private static HashSet<Integer> union(HashSet<Integer> X, HashSet<Integer> Y)
	{
		HashSet<Integer> R=new HashSet<>();
		for (int elemento:X)
		{
			R.add(elemento);
		}
		for(int elemento:Y)
		{
			R.add(elemento);
		}
			
		return R;
	}
	
	private static HashSet<Integer> interseccion(HashSet<Integer> X, HashSet<Integer> Y)
	{
		HashSet<Integer> intersection = new HashSet<Integer>(X);
		intersection.retainAll(Y);
			
		return intersection;
	}
	
	private static HashSet<Integer> diferencia(HashSet<Integer> X, HashSet<Integer> Y)
	{
		HashSet<Integer> K= new HashSet<>();
		K.addAll(X);
		K.removeAll(Y);
		return K;
	}
	
}

